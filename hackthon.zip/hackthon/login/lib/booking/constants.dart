import 'package:flutter/material.dart';
const List<String> categories = ['Academic', 'Psychological', 'Relationship'];
const List<String> months = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December'
];
const Color activeDateCardColor = Color(0xFF50A9E2);
const Color inactiveCardColor = Colors.white;
const Color activeTimeCardColor = Color(0xFFCAEAFB);